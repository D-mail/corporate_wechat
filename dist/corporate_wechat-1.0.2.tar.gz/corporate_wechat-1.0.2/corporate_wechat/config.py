#!/usr/bin/python

# -*- encoding:utf8 -*-

CROP_ID = "wx0ab38adca431331b";
CROP_SECRET = "bjeXgsLhsKAyX54Fy3J_1CdBStyUNDvorX4581M7FlM0DZsFQ3A8xYtE6dpZqaLf";